<html>
<head>
<title>Simple php test</title>
</head>
<body>
This is a simple php test

<?php phpinfo() ?>
</body>
</html>
